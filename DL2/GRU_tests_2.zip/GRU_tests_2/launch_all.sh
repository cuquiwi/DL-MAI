#!/bin/bash
echo THIS FILE DOES NOT WORK
echo THIS FILE DOES NOT WORK
echo THIS FILE DOES NOT WORK
echo yet
bash ./*/launcher.sh
